-- TABLA DISCO
CREATE TABLE discos (
    id_disco int NOT NULL AUTO_INCREMENT,
    cd_nom varchar(255) NOT NULL,
    cd_can varchar(255),
    cd_dur varchar(10),
    cd_anio int,
    cd_completo varchar(500),
    PRIMARY KEY (id_disco)
);

-- TABLA CONTENIDO DE CADA DISCO
CREATE TABLE canciones (
track_id int NOT NULL AUTO_INCREMENT,
track_nombre	varchar(30),
track_duracion	varchar(30),
track_colaborador	varchar(200),
track_letra	varchar(2000),
track_track	int(2),			
id_disco	int(6),		
cd_nombre	varchar(30),
c_video		varchar(255),
PRIMARY KEY (track_id)
);

CREATE TABLE videos (
video_id int NOT NULL AUTO_INCREMENT,
video_nombre	varchar(30),
video_duracion	varchar(30),
c_video		varchar(255),
PRIMARY KEY (video_id)
);


CREATE TABLE notas (
nota_id int NOT NULL AUTO_INCREMENT,
nota_nombre	varchar(30),
nota_duracion	varchar(30),
nota_video		varchar(255),
PRIMARY KEY (nota_id)
);


CREATE TABLE ineditos (
inedito_id int NOT NULL AUTO_INCREMENT,
inedito_nombre	varchar(30),
inedito_duracion	varchar(30),
inedito_video		varchar(255),
PRIMARY KEY (inedito_id)
);