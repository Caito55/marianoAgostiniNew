<?php
//include_once "acceso_bd.php";
include("../acceso_bd.php");
//sleep(1);


$respuestaOK = false;
$mensajeError = "No se puede ejecutar la aplicación";
$contenidoOK = "";  

$id_disco ="";
$id_disco = trim($_POST['disco']);

/*        $mysqli = conexionBD(); // Conexion a la Base Hackaton

        $res_diferente= "";
        
        //$diferente = $mysqli->query("SELECT * FROM discos  WHERE id_disco = 1 ");        
        // SOLO
        $contenido_diferente = $mysqli->query("SELECT * FROM canciones where track_id = 1 and id_disco = 1");
        while($row_dif = $contenido_diferente -> fetch_array(MYSQLI_ASSOC))
        {            
            $letra_solo_1 = $row_dif['track_letra'];
            $c_nombre = $row_dif['track_nombre'];
            $c_duracion = $row_dif['track_duracion'];
            $c_colaborador = $row_dif['track_colaborador'];
            //$c_video_s1 = $row_solo['c_video'];
        }

$res_diferente .='<div id="cdnadamas" class="">                         
                        <h2>Album '.$c_nombre.'</h2>
      				</div>';
*/

//$res_diferente .='	<p>'.$c_nombre.'</p> ' ;
//$res_diferente = $c_nombre;
    

//////////////////////////////////////////////////
/////////////////////////////////////////////////
// FUNCION ABRE DISCO DIFERENTE //


   function diferente(){
        $resp_diferente= "";

          $mysqli = conexionBD(); // Conexion a la Base Hackaton
          $disco_diferente = $mysqli->query("SELECT * FROM discos  WHERE id_disco = 1 ");   
         
            while($res_ver = $disco_diferente -> fetch_array(MYSQLI_ASSOC))
            {
                $agradecimientos = $res_ver['cd_gracias'];
                $nombredisco  = $res_ver['cd_nom'];


        // CORAZONCITO
        $contenido_track1_diferente = $mysqli->query("SELECT * FROM canciones where id_disco = 1 and track_track = 1");
        while($row_diferente1 = $contenido_track1_diferente -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_diferente1 = $row_diferente1['track_track'];
            $letra_diferente_1 = $row_diferente1['track_letra'];
            $c_nombre_diferente1 = $row_diferente1['track_nombre'];
            $c_duracion_diferente1 = $row_diferente1['track_duracion'];
            $c_colaborador_diferente1 = $row_diferente1['track_colaborador'];
            //$c_video_verdadero1 = $row_verdadero1['c_video'];
        }  
/*
        $contenido_track2_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 2");
        while($row_verdadero2 = $contenido_track2_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero2 = $row_verdadero2['c_track'];
            $letra_verdadero_2 = $row_verdadero2['c_letra'];
            $c_nombre_verdadero2 = $row_verdadero2['c_nombre'];
            $c_duracion_verdadero2 = $row_verdadero2['c_duracion'];
            $c_colaborador_verdadero2 = $row_verdadero2['c_colaborador'];
            //$c_video_verdadero2 = $row_verdadero2['c_video'];
        }  

        $contenido_track3_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 3");
        while($row_verdadero3 = $contenido_track3_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero3 = $row_verdadero3['c_track'];
            $letra_verdadero_3 = $row_verdadero3['c_letra'];
            $c_nombre_verdadero3 = $row_verdadero3['c_nombre'];
            $c_duracion_verdadero3 = $row_verdadero3['c_duracion'];
            $c_colaborador_verdadero3 = $row_verdadero3['c_colaborador'];
            //$c_video_verdadero3 = $row_verdadero3['c_video'];
        }  

        $contenido_track4_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 4");
        while($row_verdadero4 = $contenido_track4_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero4 = $row_verdadero4['c_track'];
            $letra_verdadero_4 = $row_verdadero4['c_letra'];
            $c_nombre_verdadero4 = $row_verdadero4['c_nombre'];
            $c_duracion_verdadero4 = $row_verdadero4['c_duracion'];
            $c_colaborador_verdadero4 = $row_verdadero4['c_colaborador'];
            //$c_video_verdadero4 = $row_verdadero4['c_video'];
        }  

        $contenido_track5_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 5");
        while($row_verdadero5 = $contenido_track5_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero5 = $row_verdadero5['c_track'];
            $letra_verdadero_5 = $row_verdadero5['c_letra'];
            $c_nombre_verdadero5 = $row_verdadero5['c_nombre'];
            $c_duracion_verdadero5 = $row_verdadero5['c_duracion'];
            $c_colaborador_verdadero5 = $row_verdadero5['c_colaborador'];
            //$c_video_verdadero5 = $row_verdadero5['c_video'];
        }  

        $contenido_track6_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 6");
        while($row_verdadero6 = $contenido_track6_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero6 = $row_verdadero6['c_track'];
            $letra_verdadero_6 = $row_verdadero6['c_letra'];
            $c_nombre_verdadero6 = $row_verdadero6['c_nombre'];
            $c_duracion_verdadero6 = $row_verdadero6['c_duracion'];
            $c_colaborador_verdadero6 = $row_verdadero6['c_colaborador'];
            //$c_video_verdadero6 = $row_verdadero6['c_video'];
        }  

        $contenido_track7_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 7");
        while($row_verdadero7 = $contenido_track7_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero7 = $row_verdadero7['c_track'];
            $letra_verdadero_7 = $row_verdadero7['c_letra'];
            $c_nombre_verdadero7 = $row_verdadero7['c_nombre'];
            $c_duracion_verdadero7 = $row_verdadero7['c_duracion'];
            $c_colaborador_verdadero7 = $row_verdadero7['c_colaborador'];
            //$c_video_verdadero7 = $row_verdadero7['c_video'];
        }  

        $contenido_track8_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 8");
        while($row_verdadero8 = $contenido_track8_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero8 = $row_verdadero8['c_track'];
            $letra_verdadero_8 = $row_verdadero8['c_letra'];
            $c_nombre_verdadero8 = $row_verdadero8['c_nombre'];
            $c_duracion_verdadero8 = $row_verdadero8['c_duracion'];
            $c_colaborador_verdadero8 = $row_verdadero8['c_colaborador'];
            //$c_video_verdadero8 = $row_verdadero8['c_video'];
        }  

        $contenido_track9_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 9");
        while($row_verdadero9 = $contenido_track9_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero9 = $row_verdadero9['c_track'];
            $letra_verdadero_9 = $row_verdadero9['c_letra'];
            $c_nombre_verdadero9 = $row_verdadero9['c_nombre'];
            $c_duracion_verdadero9 = $row_verdadero9['c_duracion'];
            $c_colaborador_verdadero9 = $row_verdadero9['c_colaborador'];
            //$c_video_verdadero9 = $row_verdadero9['c_video'];
        }  

        $contenido_track10_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 10");
        while($row_verdadero10 = $contenido_track10_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero10 = $row_verdadero10['c_track'];
            $letra_verdadero_10 = $row_verdadero10['c_letra'];
            $c_nombre_verdadero10 = $row_verdadero10['c_nombre'];
            $c_duracion_verdadero10 = $row_verdadero10['c_duracion'];
            $c_colaborador_verdadero10 = $row_verdadero10['c_colaborador'];
            //$c_video_verdadero10 = $row_verdadero10['c_video'];
        }  

        $contenido_track11_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 11");
        while($row_verdadero11 = $contenido_track11_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero11 = $row_verdadero11['c_track'];
            $letra_verdadero_11 = $row_verdadero11['c_letra'];
            $c_nombre_verdadero11 = $row_verdadero11['c_nombre'];
            $c_duracion_verdadero11 = $row_verdadero11['c_duracion'];
            $c_colaborador_verdadero11 = $row_verdadero11['c_colaborador'];
            //$c_video_verdadero11 = $row_verdadero11['c_video'];
        }  

        $contenido_track12_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 12");
        while($row_verdadero12 = $contenido_track12_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero12 = $row_verdadero12['c_track'];
            $letra_verdadero_12 = $row_verdadero12['c_letra'];
            $c_nombre_verdadero12 = $row_verdadero12['c_nombre'];
            $c_duracion_verdadero12 = $row_verdadero12['c_duracion'];
            $c_colaborador_verdadero12 = $row_verdadero12['c_colaborador'];
            //$c_video_verdadero12= $row_verdadero12['c_video'];
        }                                                                                          
*/
        $resp_diferente .='
                        <div id="cd_verdadero" class="collapse hidden"> <!--  Comienza disco SIN LIMITE -->
                        <!-- Abre id#cd_sim -->
                        <h2>Album '.$nombredisco.' </h2>

                        <!-- COMIENZA PESTAnAS -->
                        <ul class="nav nav-tabs">
                          <li class="active"><a data-toggle="tab" href="#home_verdadero">Inicio</a></li>
                          <li><a data-toggle="tab" href="#cd8">CD</a></li>
                          <!--<li><a data-toggle="tab" href="#menu2">Menu 2</a></li>-->
                        </ul>

                        <div class="tab-content">
                        <!-- COMIENZA TAB HOME -->    
                          <div id="home_verdadero" class="tab-pane fade in active">
                            <h3>Agradecimientos</h3>
                            <p><small><h5>
                            '.$agradecimientos.'
                            <strong>Daniel Agostini</strong>
                            </h5></small></p>
                          </div>
                          <!-- TERMINA TAB HOME -->    

                          <!-- COMIENZA TAB CD -->    
                          <div id="cd8" class="tab-pane fade">
                            
                            <h3>Lista de canciones</h3>
                          
        
                              <h4>Daniel Agostini</h4>
                              <p><small>
                              Disco compacto VERDADERO AMOR ganador de los Premios Gardel.
                              Contiene 4 covers en dos canciones enganchados.<br>
                              <strong>Nada que ver/Chica sexy</strong>
                              <strong>Dime dime/Arrepentida en la vida andaras</strong> <br>
                              

                                <!-- **************************************** -->    
                                <!-- COMIENZA ESCUCHAR CD COMPLETO "SIN LIMITE" -->
                                <a href="#solo" id="cresp_diferente_full" valor="8" data-toggle="collapse" data-target="#cdcompleto8" class="btn btn-info btn-xs">Escuchar CD Completo</a>

                                <div id="cdcompleto8" class="col-xs-12 collapse ">
                                    <h4>Disco Completo</h4>

                                    <p id="full_cresp_diferente" > </p>

                                </div>
                                <!-- TERMINA ESCUCHAR CD COMPLETO "SIN LIMITE" -->
                                <!-- **************************************** --> 



                               </small></p><br>
                              <table class="table table-condensed">
                                <thead>
                                  <tr>
                                    <th>Nº</th>
                                    <th>Nombre de la cancion</th>
                                  </tr>
                                </thead>
                                <tbody>
                                
                                <!-- TEMA 1 A PARTIR DE HOY-->
                                <tr>
                                    <td>'.$cd_track_diferente1.'</td>
                                    <td>'.$c_nombre_diferente1.'
                                   <a href="#sim" id="tema_verdadero_1" data-toggle="collapse" data-target="#apartirv" class="btn btn-info btn-xs">Escuchar</a>
                                    | <a href="#ver_cdsolo" id="dc_sim" data-toggle="collapse" data-target="#apartirl" class="btn btn-info btn-xs">Letra</a></p>
<form id="cd_verdadero_track_1">
    <input id="id_disco" name="disco" value="8" class="hidden">
    <input id="id_video" name="video" value="1" class="hidden">
</form>

                                    <!-- VIDEO --><br>
                                    <div id="apartirv" class="col-xs-12 collapse">                                  
                                    <!-- ACA VA EL VIDEO -->
                                    </div>
                                    <!-- VIDEO -->

                                    <!-- LETRA  -->
                                    <div id="apartirl" class="col-xs-12 collapse"><br>
                                    <table class="table table-condensed">
                                        <thead>
                                            <tr>
                                                <th><h3>'.$c_nombre_diferente1.' <small>Duracion: <b>'.$c_duracion_diferente1.'
                                                </b></small></h3><small>'.$c_colaborador_diferente1.'</small></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <p>
                                                    '.$letra_diferente_1.'
                                                    </p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    </div>
                                    <!-- LETRA  -->

                                   </td>
                                </tr> 
                                <!-- TEMA 1 A PARTIR DE HOY-->  


                              

                                                                                                                                                  

                                        </tbody>
                                    </table>
                                </div>
                                </td>
                                </tr>

                                <!--
                                  <tr>
                                    <td></td>
                                    <td></td>
                                  </tr>
                              -->
                                </tbody>
                              </table>
                            </div> <!-- Cierra CD -->                           


                           
                          </div>
                          <!-- TERMINA TAB HOME -->    



                          <!--
                          <div id="menu2" class="tab-pane fade">
                            <h3>Menu 2</h3>
                            <p>Some content in menu 2.</p>
                          </div>
                          -->

                        </div>
                        <!-- TERMINA PESTAnAS -->


                        <!-- Cierra id#cd_solo -->    
                        </div>                   
              ';
          }
    //return $resp_diferente;          
    }           

////////////////////////////////////////////////
////////////////////////////////////////////////      				



$respuestaOK = true;
$mensajeError = "No se puede ejecutar la aplicación";
$contenidoOK = $resp_diferente; 

//$respuestaOK = true;
//$mensajeError = "No se puede ejecutar la aplicación";
//$contenidoOK = $res_diferente;  


$salidaJson = array("respuesta" => $respuestaOK,
                    "mensaje" => $mensajeError,
                    "contenido" => $contenidoOK );

echo json_encode($salidaJson);   

?>