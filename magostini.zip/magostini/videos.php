<?php //include("discos.php");  ?>
<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" type="text/css" href="css/video.css">
		<script type="text/javascript" src="js/video.js"></script>
</head>



<!-- VIDEOS -->
  <div class="card" style="width:auto" align="center" id="videos_div">
    <img class="card-img-top" src="image/pasarlabien.png"  style="width:100%">
    <div class="card-body">
      <h4 class="card-title">Shows En Vivo</h4><hr>
      <p class="card-text"></p>
      <!--<a href="#video" class="btn btn-primary btn-block" data-toggle="collapse">Videos</a>-->

       <!-- VIDEO DE LA ENTREVISTA -->
            <div id="muestra_video" class="collapse"> <br>
                <!--<button id="cerrar_tema" class="btn btn-info btn-block hidden">Ineditos</button>-->
                <div id="vervideo"></div>
            </div>
       <!-- VIDEO DE LA ENTREVISTA -->    


  	<!-- TABLA VIDEOS -->
	<table class="table " cellpadding="0" cellspacing="0" border="0" width="auto" id="listavideo">
	    <thead>
	       <tr>
	         <th>Nº</th>
	         <th>Nombre</th>
	         <th>Reproducir</th>
	       </tr>
	    </thead>
	     <tbody>
	         <?php echo ver_videos(); ?>
	   </tbody>	              
	</table>  	
  	<!-- TABLA VIDEOS -->
  	         
    </div>
  </div> 
<!-- VIDEOS -->
	
  

 

<?php
    function ver_videos(){
        $salida = "";
        $mysqli = conexionBD();
        $contenido_inedito = $mysqli->query("SELECT * FROM videos ");
        while($row_i = $contenido_inedito -> fetch_array(MYSQLI_ASSOC))
        {            

            $salida.='
                  <tr>
                    <td><small>'.$row_i['video_id'].'</small></td>
                    <td><small>'.$row_i['video_nombre'].'</small>

                    </td>
                    <td>
                    <a  tema="'.$row_i['video_id'].'" id="abrir_video" data-toggle="collapse" data-target="#muestra_video">
                    <small> <img src="image/play.png" width="30" height="30" alt="Play" /> 
                    </small></a>
                    </td>
                  </tr>
               

                ';
            } // Cierra While
            return $salida;

        }// Cierra funcion ii
?>